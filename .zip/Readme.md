This is a project on an app similar to youtube.

<!-- you cannot commit empty folders on git -->

<!-- if you want to commit an empty folder, add a '.gitkeep' file in that folder -->


<!-- using '-D'/'--save-dev' while installing npm package makes it a dev depencdency instead of main dependency -->