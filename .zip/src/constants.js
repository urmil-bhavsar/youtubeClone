export const DB_NAME = "videotube"


// export default DB_NAME