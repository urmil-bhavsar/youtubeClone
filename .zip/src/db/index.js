import mongoose from "mongoose";
import { DB_NAME } from "../constants";

// db is in another continent, it might even take time to connect to it, so mark it as async/await
const connectDB = async () => {
    mongoose.connect()
}